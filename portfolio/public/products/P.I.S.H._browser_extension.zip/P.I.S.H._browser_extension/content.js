// content.js - injected into all pages
// Extracts forensics and manages on-page alerts and monitoring.

// Simple debounce helper
function debounce(fn, delay) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), delay);
  };
}

// Extract forensics from current page
async function extractForensics() {
  try {
    const url = window.location.href;
    if (!url.startsWith("http")) return;

    const fullText = document.body ? document.body.innerText || "" : "";

    const linkElements = Array.from(document.querySelectorAll("a[href]"));
    const links = linkElements.map((a) => a.href).filter(Boolean);

    const attachmentExtensions = [
      ".pdf",
      ".doc",
      ".docx",
      ".xls",
      ".xlsx",
      ".zip",
      ".rar",
      ".7z",
      ".exe",
      ".msi",
    ];
    const attachments = linkElements
      .map((a) => a.href)
      .filter((href) =>
        attachmentExtensions.some((ext) =>
          href.toLowerCase().includes(ext)
        )
      )
      .map((href) => ({ url: href }));

    // Placeholder QR detection: real implementation would use jsQR or similar
    const qrCodes = [];
    console.log("[Content] Attachments found:", attachments.length);

    const metadata = {
      title: document.title,
      url,
      referrer: document.referrer,
      timestamp: new Date().toISOString(),
    };
    console.log("[Content] Metadata:", metadata);

    console.log("[Content] Sending PG_SAVE_FORENSICS message");
    chrome.runtime.sendMessage(
      {
        type: "PG_SAVE_FORENSICS",
        payload: {
          url,
          fullText,
          links,
          attachments,
          qrCodes,
          metadata,
        },
      },
      () => {
        // Ignore connection errors (background script may not be ready)
        if (chrome.runtime.lastError) {
          console.log("[Content] Message send error (expected if background not ready):", chrome.runtime.lastError.message);
        } else {
          console.log("[Content] Forensics message sent successfully");
        }
      }
    );
  } catch (e) {
    console.error("[Content] Forensics extraction failed:", e);
  }
}

const debouncedExtract = debounce(extractForensics, 1000);

chrome.runtime.onMessage.addListener((message) => {
  if (message.type === "PG_EXTRACT_FORENSICS") {
    debouncedExtract();
  } else if (message.type === "PG_START_MONITORING") {
    startIntensiveMonitoring(message.payload.pageEventId);
  } else if (message.type === "PG_SHOW_MALICIOUS_ALERT") {
    showMaliciousOverlays(message.payload);
  }
});

// One-time and persistent malicious overlays
let maliciousPopupShown = false;
let persistentBanner;

function showMaliciousOverlays(payload) {
  const { attackType, phishingScore } = payload || {};

  if (!maliciousPopupShown) {
    maliciousPopupShown = true;
    const modal = document.createElement("div");
    modal.style.position = "fixed";
    modal.style.top = "0";
    modal.style.left = "0";
    modal.style.right = "0";
    modal.style.bottom = "0";
    modal.style.background = "rgba(0,0,0,0.6)";
    modal.style.zIndex = "2147483646";
    modal.style.display = "flex";
    modal.style.alignItems = "center";
    modal.style.justifyContent = "center";

    const box = document.createElement("div");
    box.style.background = "#fff";
    box.style.padding = "16px 20px";
    box.style.borderRadius = "8px";
    box.style.maxWidth = "420px";
    box.style.boxShadow = "0 4px 12px rgba(0,0,0,0.3)";
    box.style.fontFamily = "system-ui, -apple-system, BlinkMacSystemFont, sans-serif";
    box.innerHTML = `
      <h2 style="margin-top:0;color:#c0392b;">Malicious page detected</h2>
      <p>This page has been flagged as potentially malicious.</p>
      <p><strong>Attack type:</strong> ${attackType || "Unknown"}</p>
      <p><strong>Phishing score:</strong> ${phishingScore ?? "N/A"}</p>
      <div style="margin-top:12px;display:flex;gap:8px;justify-content:flex-end;">
        <button id="pg-quarantine-btn" style="background:#e74c3c;border:none;color:#fff;padding:6px 10px;border-radius:4px;cursor:pointer;">Quarantine (Google)</button>
        <button id="pg-close-modal" style="padding:6px 10px;border-radius:4px;border:1px solid #ccc;cursor:pointer;">Close</button>
      </div>
    `;
    modal.appendChild(box);
    document.documentElement.appendChild(modal);

    box.querySelector("#pg-close-modal").onclick = () => {
      modal.remove();
    };
    box.querySelector("#pg-quarantine-btn").onclick = () => {
      window.open("https://myaccount.google.com/security", "_blank");
    };
  }

  if (!persistentBanner) {
    persistentBanner = document.createElement("div");
    persistentBanner.style.position = "fixed";
    persistentBanner.style.bottom = "12px";
    persistentBanner.style.right = "12px";
    persistentBanner.style.zIndex = "2147483645";
    persistentBanner.style.background = "#2c3e50";
    persistentBanner.style.color = "#ecf0f1";
    persistentBanner.style.padding = "10px 14px";
    persistentBanner.style.borderRadius = "8px";
    persistentBanner.style.fontSize = "13px";
    persistentBanner.style.maxWidth = "320px";
    persistentBanner.style.boxShadow = "0 3px 10px rgba(0,0,0,0.4)";
    persistentBanner.style.fontFamily =
      "system-ui, -apple-system, BlinkMacSystemFont, sans-serif";
    persistentBanner.innerHTML = `
      <div style="font-weight:600;margin-bottom:4px;">Phishing Guardian Alert</div>
      <div style="margin-bottom:6px;">This page is flagged as malicious.</div>
      <div style="margin-bottom:6px;"><strong>Attack:</strong> ${attackType || "Unknown"}</div>
      <div style="margin-bottom:6px;"><strong>Score:</strong> ${phishingScore ?? "N/A"}</div>
      <div id="pg-news" style="max-height:90px;overflow:auto;font-size:12px;margin-top:4px;border-top:1px solid rgba(236,240,241,0.3);padding-top:4px;">
        Loading latest phishing news...
      </div>
      <div style="margin-top:8px;display:flex;gap:6px;justify-content:flex-end;">
        <button id="pg-banner-quarantine" style="background:#e74c3c;border:none;color:#fff;padding:4px 8px;border-radius:4px;cursor:pointer;font-size:12px;">Quarantine</button>
      </div>
    `;
    document.documentElement.appendChild(persistentBanner);

    persistentBanner
      .querySelector("#pg-banner-quarantine")
      .addEventListener("click", () => {
        window.open("https://myaccount.google.com/security", "_blank");
      });

    loadPhishingNews();
  }
}

async function loadPhishingNews() {
  const el = document.getElementById("pg-news");
  if (!el) return;
  try {
    el.textContent = "Recent phishing incidents: ";
    el.insertAdjacentHTML(
      "beforeend",
      "<ul><li>Phishing campaigns using QR codes to steal credentials.</li><li>Spear-phishing targeting corporate email accounts.</li><li>Malicious attachments delivering remote-access trojans.</li></ul>"
    );
  } catch (e) {
    el.textContent = "Failed to load phishing news.";
  }
}

// Click monitoring (to notify extension when user clicks any link)
document.addEventListener(
  "click",
  (e) => {
    const a = e.target.closest && e.target.closest("a[href]");
    if (a && a.href) {
      console.log("[Content] Link clicked:", a.href);
      chrome.runtime.sendMessage(
        {
          type: "PG_USER_CLICKED_LINK",
          payload: { href: a.href },
        },
        () => {
          if (chrome.runtime.lastError) {
            console.log("[Content] Click message error:", chrome.runtime.lastError.message);
          } else {
            console.log("[Content] Click message sent successfully");
          }
        }
      );
    }
  },
  true
);

// Intensive monitoring on malicious pages after risky click
let monitoringActive = false;
let monitoringPageEventId = null;

function startIntensiveMonitoring(pageEventId) {
  console.log("[Content] Starting intensive monitoring for page_event:", pageEventId);
  if (monitoringActive) {
    console.log("[Content] Monitoring already active, skipping");
    return;
  }
  monitoringActive = true;
  monitoringPageEventId = pageEventId;
  console.log("[Content] Monitoring activated, attaching event listeners");

  document.addEventListener(
    "click",
    (e) => {
      const tgt = e.target;
      const selector = getCssSelector(tgt);
      const payload = {
        selector,
        x: e.clientX,
        y: e.clientY,
        text:
          (tgt && tgt.textContent || "").slice(0, 100),
      };
      sendMonitoringEvent("click", payload);
    },
    true
  );

  document.addEventListener(
    "keydown",
    (e) => {
      const payload = {
        key: e.key,
        targetType: e.target && e.target.tagName,
        isPassword:
          e.target &&
          e.target.tagName === "INPUT" &&
          e.target.type === "password",
      };
      sendMonitoringEvent("keydown", payload);
    },
    true
  );
}

function getCssSelector(el) {
  if (!(el instanceof Element)) return "";
  const path = [];
  while (el && path.length < 5) {
    let selector = el.nodeName.toLowerCase();
    if (el.id) {
      selector += `#${el.id}`;
      path.unshift(selector);
      break;
    } else {
      const sibs = Array.from(el.parentNode?.children || []);
      const index = sibs.indexOf(el);
      if (index >= 0) selector += `:nth-child(${index + 1})`;
    }
    path.unshift(selector);
    el = el.parentElement;
  }
  return path.join(" > ");
}

async function sendMonitoringEvent(eventType, eventPayload) {
  try {
    chrome.storage.local.get(["pg_user"], (data) => {
      const user = data.pg_user || null;
      chrome.runtime.sendMessage(
        {
          type: "PG_MONITORING_EVENT",
          payload: {
            userId: user ? user.id : null,
            pageEventId: monitoringPageEventId,
            eventType,
            eventPayload,
          },
        },
        () => {
          if (chrome.runtime.lastError) {
            // Silently ignore
          }
        }
      );
    });
  } catch (e) {
    // eslint-disable-next-line no-console
    console.error("Failed to send monitoring event", e);
  }
}



