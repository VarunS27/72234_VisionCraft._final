// parallel_lb.js
// Simple TaskPool: concurrency-limited parallel processing with FIFO load balancing.
// Works in Node (CommonJS). Each "worker" is a logical slot that executes async tasks.

class TaskPool {
  constructor(concurrency = 4) {
    if (!Number.isInteger(concurrency) || concurrency <= 0) {
      throw new Error('concurrency must be a positive integer');
    }
    this.concurrency = concurrency;
    this.queue = [];
    this.active = 0;
  }

  // taskFn: () => Promise|any
  // Returns a Promise that resolves/rejects with task result.
  run(taskFn) {
    return new Promise((resolve, reject) => {
      this.queue.push({ taskFn, resolve, reject });
      this._next();
    });
  }

  // Internal: start jobs while we have capacity and queued tasks.
  _next() {
    while (this.active < this.concurrency && this.queue.length > 0) {
      const job = this.queue.shift(); // FIFO -> simple load balancing
      this.active += 1;

      // Execute the taskFn and settle the promise.
      Promise.resolve()
        .then(() => job.taskFn())
        .then((res) => {
          this.active -= 1;
          job.resolve(res);
          this._next();
        })
        .catch((err) => {
          this.active -= 1;
          job.reject(err);
          this._next();
        });
    }
  }

  // Helper: run an array of task functions with the pool.
  // taskFns: Array<() => Promise|any>
  runAll(taskFns) {
    return Promise.all(taskFns.map((fn) => this.run(fn)));
  }

  // Optional: returns number of queued tasks
  queued() {
    return this.queue.length;
  }

  // Optional: returns number of active tasks
  activeCount() {
    return this.active;
  }
}

module.exports = TaskPool;

// Usage example / quick test harness. Run with `node parallel_lb.js`.
if (typeof require !== 'undefined' && require.main === module) {
  const pool = new TaskPool(3);

  // Create 10 dummy tasks that complete after a random timeout
  const tasks = Array.from({ length: 10 }, (_, i) => {
    return () =>
      new Promise((resolve) => {
        const delay = 200 + Math.floor(Math.random() * 1000);
        setTimeout(() => {
          console.log(`task ${i} done (delay ${delay}ms)`);
          resolve(i);
        }, delay);
      });
  });

  console.log('Submitting tasks...');
  pool
    .runAll(tasks)
    .then((results) => {
      console.log('All tasks finished. Results:', results);
    })
    .catch((err) => {
      console.error('Error running tasks:', err);
    });
}
