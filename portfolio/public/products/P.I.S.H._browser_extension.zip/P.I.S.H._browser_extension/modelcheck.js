fetch("https://generativelanguage.googleapis.com/v1/models?key=AIzaSyAAHZ6KiTjTKP2qWWDz-cTfWeAwKY312ag")
  .then(res => res.json())
  .then(console.log);
